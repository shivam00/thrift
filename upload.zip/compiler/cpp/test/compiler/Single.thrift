const string foo = "bar"
