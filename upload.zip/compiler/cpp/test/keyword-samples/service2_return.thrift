service service_name {
  bool function_name(1: i32 return)
}
