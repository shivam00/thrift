typedef bool return
