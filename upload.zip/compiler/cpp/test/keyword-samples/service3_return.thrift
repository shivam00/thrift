service service_name {
  void return()
}
